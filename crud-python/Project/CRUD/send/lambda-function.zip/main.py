import boto3
import json
import os
from botocore.exceptions import ClientError

AWS_REGION = 'us-east-1'
AWS_PROFILE = 'localstack'
ENDPOINT_URL = 'http://localhost:4566'

boto3.setup_default_session(profile_name=AWS_PROFILE)
dynamodb_resource = boto3.resource("dynamodb", region_name=AWS_REGION, endpoint_url=ENDPOINT_URL)
dynamodb_client = boto3.client("dynamodb", region_name=AWS_REGION, endpoint_url=ENDPOINT_URL)

def main(event, context):
	# Obter os parâmetros do evento, se necessário
	function_name = event.get('function_name')
	table_name = event.get('table_name')
	object_name = event.get('object_name')
	content = event.get('content')

	# Chamar as funções conforme necessário
	if function_name == 'add_dynamodb_table_item':
		add_dynamodb_table_item(table_name, 'wagratom')
	elif function_name == 'delete_dynamodb_table_item':
		delete_dynamodb_table_item(table_name, 'wagratom')
	elif function_name == 'read_dynamodb_table_item':
		read_dynamodb_table_item(table_name, 'wagratom')

def add_dynamodb_table_item(table_name, name):
	table = dynamodb_resource.Table(table_name)
	response = table.put_item(
		Item={
			'Name': name,
		}
	)
	return response

def delete_dynamodb_table_item(table_name, name):
	table = dynamodb_resource.Table(table_name)
	response = table.delete_item(
		Key={
			'Name': name,
		}
	)
	return response

def read_dynamodb_table_item(table_name, name):
	table = dynamodb_resource.Table(table_name)
	response = table.get_item(
		Key={
			'Name': name,
		}
	)
	return response
